const express = require('express');
const router = express.Router();

const data = [
  { id: 1, step: 'PASSO 1', description: 'Explore nossa página dedicada aos cuidados essenciais para a sua pele, onde encontrará orientações valiosas para manter uma rotina de cuidados diários que realçam sua beleza natural.' },
  { id: 2, step: 'PASSO 2', description: 'Após avaliar a foto enviada, será indicada uma rotina de cuidados com a pele de acordo com seu tipo de pele.' },
  { id: 3, step: 'PASSO 3', description: 'Após os primeiros passos, serão disponibilizadas algumas dicas para complementar sua rotina de cuidados com a pele e auxiliar no seu dia a dia.' }
];

// Listar todos os passos
router.get('/steps', (req, res) => {
  res.json(data);
});

// Obter um passo específico por ID
router.get('/steps/:id', (req, res) => {
  const step = data.find(item => item.id === parseInt(req.params.id));
  if (step) {
    res.json(step);
  } else {
    res.status(404).json({ message: 'Passo não encontrado' });
  }
});

module.exports = router;
